<template>
      <form>
        <v-text-field
          v-model="name"
          :counter="10"
          label="Name"
          required
        ></v-text-field>
        <v-text-field v-model="email" label="E-mail" required></v-text-field>

        <v-btn class="mr-4">submit</v-btn>
        <v-btn>clear</v-btn>
      </form>
</template>