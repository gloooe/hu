import Vue from 'vue'
import Vuex from 'vuex'
import account from './module/account'
import menu from './module/permission'
import tagView from './module/tagCacheView'
import pagestatus from './module/pagestatus'
Vue.use(Vuex)
const store = new Vuex.Store({
  modules: {
    pagestatus,
    account,
    menu,
    tagView
  }
})

export default store
