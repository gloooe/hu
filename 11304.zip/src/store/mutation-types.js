export const ACCOUNTINFO = 'accountInfo' // 用户信息
export const SINGOUT = 'signout' // 退出登陆
export const RULES = 'rules' // 用户权限
export const MENU = 'menu' // 菜单
export const DELNOWTAG = 'delNowTag' // 删除标签
export const TAGSHOWVIEW = 'tagShowView' // 显示的标签
